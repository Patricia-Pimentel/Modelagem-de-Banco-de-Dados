-- ###############################################################
-- # SCRIPT DDL - PROJETO FÍSICO: ILUMINAÇÃO INTELIGENTE CIDADE #
-- # BANCO DE DADOS: PostgreSQL 15                               #
-- ###############################################################

-- -------------------------------------------------------------
-- 1. Criação das Tabelas Base (sem dependências de FK)
-- -------------------------------------------------------------

-- Entidade: Local
-- Atributos: Codigo1 (PK), Nome local, Ativacao Local
CREATE TABLE local (
    codigo_local SERIAL PRIMARY KEY, -- SERIAL para auto-incremento de ID
    nome_local VARCHAR(100) NOT NULL,
    ativacao_local BOOLEAN NOT NULL DEFAULT TRUE -- Ou DATE se for data de ativação
);

-- Entidade: Agente
-- Atributos: ID (PK), Nome_us, Permissao
CREATE TABLE agente (
    id_agente SERIAL PRIMARY KEY, -- SERIAL para auto-incremento de ID
    nome_usuario VARCHAR(100) NOT NULL UNIQUE, -- UNIQUE para garantir nomes de usuário únicos
    permissao VARCHAR(50) NOT NULL -- Ex: 'Administrador', 'Operador', 'Técnico'
);

-- Entidade: Sensor
-- Atributos: Codigo sensor (PK), Modelo_sensor
CREATE TABLE sensor (
    codigo_sensor SERIAL PRIMARY KEY, -- SERIAL para auto-incremento de ID
    modelo_sensor VARCHAR(100) NOT NULL
);

-- Entidade: Dispositivos
-- Atributos: ID1 (PK), Nome dispositivo, Cor_dispositivo, Modelo_Dispositivo
CREATE TABLE dispositivo (
    id_dispositivo SERIAL PRIMARY KEY, -- ID1 renomeado para id_dispositivo
    nome_dispositivo VARCHAR(100) NOT NULL,
    cor_dispositivo VARCHAR(50), -- Ex: 'Branco', 'Cinza'
    modelo_dispositivo VARCHAR(100) NOT NULL
);

-- Entidade: Comando
-- Atributos: ID comando (PK), Status_comando
CREATE TABLE comando (
    id_comando SERIAL PRIMARY KEY, -- SERIAL para auto-incremento de ID
    status_comando VARCHAR(50) NOT NULL -- Ex: 'Enviado', 'Executado', 'Falha'
);

-- Entidade: Manutencao
-- Atributos: Codigo manutenção (PK), Status_manut
CREATE TABLE manutencao (
    codigo_manutencao SERIAL PRIMARY KEY, -- SERIAL para auto-incremento de ID
    status_manutencao VARCHAR(50) NOT NULL -- Ex: 'Pendente', 'Em Andamento', 'Concluída'
);


-- -------------------------------------------------------------
-- 2. Criação das Tabelas de Relacionamento (com chaves estrangeiras)
--    Seguindo as cardinalidades e os "Relacionamento_X"
-- -------------------------------------------------------------

-- Relacionamento_1: Local (0,1) --- (0,n) Dispositivos
-- Um dispositivo está em 0 ou 1 local.
-- Um local pode ter 0 ou N dispositivos.
-- A FK deve estar em Dispositivo, apontando para Local.
ALTER TABLE dispositivo
ADD COLUMN codigo_local INTEGER,
ADD CONSTRAINT fk_dispositivo_local
FOREIGN KEY (codigo_local) REFERENCES local (codigo_local);


-- Relacionamento_2: Local (0,1) --- (0,n) Sensor
-- Um sensor está em 0 ou 1 local.
-- Um local pode ter 0 ou N sensores.
-- A FK deve estar em Sensor, apontando para Local.
ALTER TABLE sensor
ADD COLUMN codigo_local INTEGER,
ADD CONSTRAINT fk_sensor_local
FOREIGN KEY (codigo_local) REFERENCES local (codigo_local);


-- Relacionamento_3: Agente (0,1) --- (0,n) Comando
-- Um comando é enviado por 0 ou 1 agente.
-- Um agente pode enviar 0 ou N comandos.
-- A FK deve estar em Comando, apontando para Agente.
ALTER TABLE comando
ADD COLUMN id_agente INTEGER,
ADD CONSTRAINT fk_comando_agente
FOREIGN KEY (id_agente) REFERENCES agente (id_agente);


-- Relacionamento_4: Dispositivos (0,n) --- (0,1) Comando
-- Um comando pode afetar 0 ou N dispositivos.
-- Um dispositivo pode receber 0 ou 1 comando.
-- Este relacionamento é um pouco mais complexo. Se um comando afeta múltiplos dispositivos,
-- e um dispositivo pode ser afetado por múltiplos comandos (ao longo do tempo),
-- seria uma tabela associativa. No seu DER, a cardinalidade (0,1) no lado do Comando
-- em relação a Dispositivos sugere que um DISPOSITIVO pode ter 0 ou 1 COMANDO associado
-- (o comando ATUAL que está sendo executado nele, talvez).
-- Se for o comando atual, a FK fica em DISPOSITIVO.
ALTER TABLE dispositivo
ADD COLUMN id_comando INTEGER,
ADD CONSTRAINT fk_dispositivo_comando
FOREIGN KEY (id_comando) REFERENCES comando (id_comando);


-- Relacionamento_5: Agente (0,1) --- (0,n) Manutencao
-- Uma manutenção é realizada por 0 ou 1 agente.
-- Um agente pode realizar 0 ou N manutenções.
-- A FK deve estar em Manutencao, apontando para Agente.
ALTER TABLE manutencao
ADD COLUMN id_agente INTEGER,
ADD CONSTRAINT fk_manutencao_agente
FOREIGN KEY (id_agente) REFERENCES agente (id_agente);


-- Relacionamento_6: Dispositivos (0,n) --- (0,n) Manutencao
-- Este é um relacionamento N:N entre Dispositivo e Manutencao.
-- Um dispositivo pode ter 0 ou N manutenções.
-- Uma manutenção pode ser para 0 ou N dispositivos.
-- Precisamos de uma tabela associativa para resolver o N:N.
CREATE TABLE dispositivo_manutencao (
    id_dispositivo INTEGER NOT NULL,
    codigo_manutencao INTEGER NOT NULL,
    PRIMARY KEY (id_dispositivo, codigo_manutencao), -- Chave primária composta
    FOREIGN KEY (id_dispositivo) REFERENCES dispositivo (id_dispositivo),
    FOREIGN KEY (codigo_manutencao) REFERENCES manutencao (codigo_manutencao)
);


-- Relacionamento_7: Sensor (0,n) --- (0,1) Dispositivos
-- Um dispositivo pode ter 0 ou N sensores.
-- Um sensor pode estar associado a 0 ou 1 dispositivo.
-- A FK deve estar em Sensor, apontando para Dispositivo.
ALTER TABLE sensor
ADD COLUMN id_dispositivo INTEGER,
ADD CONSTRAINT fk_sensor_dispositivo
FOREIGN KEY (id_dispositivo) REFERENCES dispositivo (id_dispositivo);


-- Relacionamento_8: Sensor (0,n) --- (0,n) Comando
-- Este é um relacionamento N:N entre Sensor e Comando.
-- Um sensor pode enviar 0 ou N comandos.
-- Um comando pode ser originado/influenciado por 0 ou N sensores.
-- Precisamos de uma tabela associativa para resolver o N:N.
CREATE TABLE sensor_comando (
    codigo_sensor INTEGER NOT NULL,
    id_comando INTEGER NOT NULL,
    PRIMARY KEY (codigo_sensor, id_comando), -- Chave primária composta
    FOREIGN KEY (codigo_sensor) REFERENCES sensor (codigo_sensor),
    FOREIGN KEY (id_comando) REFERENCES comando (id_comando)
);Biblia

-- ###############################################################
-- # SCRIPT DML - POPULAÇÃO DE DADOS DE EXEMPLO                #
-- # BANCO DE DADOS: PostgreSQL 15                               #
-- ###############################################################

-- Inserindo dados na tabela 'local'
INSERT INTO local (nome_local, ativacao_local) VALUES
('Praça Biblia', TRUE),
('Avenida Palmeiras', TRUE),
('Parque Cidade', FALSE), -- Exemplo de local inativo
('Rua Comercial Norte', TRUE);

-- Inserindo dados na tabela 'agente'
INSERT INTO agente (nome_usuario, permissao) VALUES
('patricia.pimentel', 'Administrador'),
('janaina.paiva', 'Operador'),
('debora.mendoca', 'Tecnico');

-- Inserindo dados na tabela 'sensor'
-- 'codigo_local' e 'id_dispositivo' serão atualizados depois
INSERT INTO sensor (modelo_sensor) VALUES
('Luminosidade GLX-100'),
('Movimento PIM-200'),
('Temperatura TM-300'),
('Qualidade do Ar AQ-400');

-- Inserindo dados na tabela 'dispositivo'
-- 'codigo_local' e 'id_comando' serão atualizados depois
INSERT INTO dispositivo (nome_dispositivo, cor_dispositivo, modelo_dispositivo) VALUES
('Luminária LED 01', 'Cinza', 'Modelo XL-500'),
('Luminária LED 02', 'Cinza', 'Modelo XL-500'),
('Poste Inteligente 01', 'Preto', 'Modelo SmartPole'),
('Sinaleira 01', 'Verde', 'Modelo TrafficLight-V3');

-- Inserindo dados na tabela 'comando'
-- 'id_agente' será atualizado depois
INSERT INTO comando (status_comando) VALUES
('Enviado'),
('Executado'),
('Falha');

-- Inserindo dados na tabela 'manutencao'
-- 'id_agente' será atualizado depois
INSERT INTO manutencao (status_manutencao) VALUES
('Pendente'),
('Em Andamento'),
('Concluída');


-- ###############################################################
-- # ATUALIZAÇÃO DE CHAVES ESTRANGEIRAS PARA OS DADOS EXISTENTES #
-- ###############################################################

-- Atualizando Sensores com 'codigo_local' e 'id_dispositivo'
UPDATE sensor SET codigo_local = 1, id_dispositivo = 1 WHERE codigo_sensor = 1; -- Sensor 1 na Praça Biblia (local 1), associado ao Dispositivo 1
UPDATE sensor SET codigo_local = 1, id_dispositivo = 1 WHERE codigo_sensor = 2; -- Sensor 2 também na Praça Biblia, Dispositivo 1
UPDATE sensor SET codigo_local = 2, id_dispositivo = 3 WHERE codigo_sensor = 3; -- Sensor 3 na Av. Principal (local 2), Dispositivo 3
UPDATE sensor SET codigo_local = 2, id_dispositivo = NULL WHERE codigo_sensor = 4; -- Sensor 4 na Av. Principal, sem dispositivo associado ainda

-- Atualizando Dispositivos com 'codigo_local' e 'id_comando'
UPDATE dispositivo SET codigo_local = 1, id_comando = 2 WHERE id_dispositivo = 1; -- Dispositivo 1 na Praça Biblia (local 1), comando 2 (Executado)
UPDATE dispositivo SET codigo_local = 1, id_comando = NULL WHERE id_dispositivo = 2; -- Dispositivo 2 na Praça Biblia, sem comando atual
UPDATE dispositivo SET codigo_local = 2, id_comando = 1 WHERE id_dispositivo = 3; -- Dispositivo 3 na Av. Principal (local 2), comando 1 (Enviado)
UPDATE dispositivo SET codigo_local = 4, id_comando = NULL WHERE id_dispositivo = 4; -- Dispositivo 4 na Rua Sec. 123 (local 4)

-- Atualizando Comandos com 'id_agente'
UPDATE comando SET id_agente = 1 WHERE id_comando = 1; -- Comando 1 feito pelo Agente 1 (patricia.pimentel)
UPDATE comando SET id_agente = 2 WHERE id_comando = 2; -- Comando 2 feito pelo Agente 2 (janaina.paiva)
UPDATE comando SET id_agente = 1 WHERE id_comando = 3; -- Comando 3 feito pelo Agente 1 (patricia.pimentelJoão)

-- Atualizando Manutenções com 'id_agente'
UPDATE manutencao SET id_agente = 3 WHERE codigo_manutencao = 1; -- Manutenção 1 feita pelo Agente 3 (debora.mendoca)
UPDATE manutencao SET id_agente = 3 WHERE codigo_manutencao = 2; -- Manutenção 2 feita pelo Agente 3 (debora.mendoca)
UPDATE manutencao SET id_agente = 2 WHERE codigo_manutencao = 3; -- Manutenção 3 feita pelo Agente 2 (janaina.paiva)


-- Inserindo dados nas tabelas associativas N:N

-- dispositivo_manutencao (Qual dispositivo recebeu qual manutenção)
INSERT INTO dispositivo_manutencao (id_dispositivo, codigo_manutencao) VALUES
(1, 1), -- Dispositivo 1 teve Manutenção 1
(1, 2), -- Dispositivo 1 também teve Manutenção 2
(3, 1); -- Dispositivo 3 teve Manutenção 1

-- sensor_comando (Qual sensor influencia qual comando)
INSERT INTO sensor_comando (codigo_sensor, id_comando) VALUES
(1, 1), -- Sensor 1 influenciou Comando 1
(2, 1), -- Sensor 2 também influenciou Comando 1
(3, 2); -- Sensor 3 influenciou Comando 2

-- ###############################################################
-- # SCRIPT DML - CONSULTAS DE MANIPULAÇÃO (INSERT/UPDATE/DELETE) #
-- # E CONSULTAS DE SELEÇÃO (SELECT)                              #
-- # BANCO DE DADOS: PostgreSQL 15                               #
-- ###############################################################

-- ===============================================================
-- EXEMPLOS DE INSERT (Já usamos muitos acima, aqui mais um)
-- ===============================================================
INSERT INTO local (nome_local, ativacao_local)
VALUES ('Rodoviário do Plano', TRUE);

-- ===============================================================
-- EXEMPLOS DE UPDATE (Atualizar Dados Existentes)
-- ===============================================================

-- 1. Alterar o nome de um local
UPDATE local
SET nome_local = 'Praça Biblia Remodelada'
WHERE codigo_local = 1; -- Altera o local com ID 1

-- 2. Mudar o status de um sensor para um dispositivo diferente
UPDATE sensor
SET id_dispositivo = 2, codigo_local = 1 -- Associa ao dispositivo 2 (da Praça Biblia)
WHERE codigo_sensor = 2; -- Sensor 2 (Movimento PIM-200)

-- 3. Mudar a permissão de um agente
UPDATE agente
SET permissao = 'Supervisor'
WHERE id_agente = 2; -- Agente 2 (janaina.paiva)

-- 4. Alterar o status de uma manutenção para concluída e o agente responsável
UPDATE manutencao
SET status_manutencao = 'Concluída', id_agente = 1 -- Concluída pelo Agente 1 (João)
WHERE codigo_manutencao = 1; -- Manutenção 1

-- ===============================================================
-- EXEMPLOS DE DELETE (Remover Dados Existentes)
-- Cuidado ao usar DELETE, pois remove permanentemente os dados.
-- Se houver FOREIGN KEYs, pode ser necessário remover primeiro os dados dependentes.
-- ===============================================================

-- Exemplo: Deletar um local que não tem dispositivos ou sensores associados (ou que sejam NULL)
-- ATENÇÃO: Se o local 3 (Parque Urbano) tiver algum FK dependente, o delete vai falhar
-- A menos que as FKs permitam NULL ou sejam cascata.

-- Primeiramente, verificar se há dependências (opcional, mas boa prática)
-- SELECT * FROM dispositivo WHERE codigo_local = 3;
-- SELECT * FROM sensor WHERE codigo_local = 3;

-- Se não houver dependências ou se você as tratou:
DELETE FROM local
WHERE codigo_local = 3; -- Remove o 'Parque Urbano Leste'

-- Exemplo: Deletar um comando (e se precisar, suas associações em sensor_comando)
-- DELETE FROM sensor_comando WHERE id_comando = 3; -- Se houver entradas
DELETE FROM comando
WHERE id_comando = 3; -- Comando 3 (Falha)

-- ===============================================================
-- EXEMPLOS DE SELECT (Consultas para Visualizar Dados)
-- ===============================================================

-- 1. Selecionar todos os locais
SELECT * FROM local;

-- 2. Selecionar todos os agentes
SELECT * FROM agente;

-- 3. Selecionar dispositivos e seus locais (JOIN)
SELECT
    d.nome_dispositivo,
    d.modelo_dispositivo,
    l.nome_local as localizacao
FROM
    dispositivo d
LEFT JOIN
    local l ON d.codigo_local = l.codigo_local;

-- 4. Selecionar manutenções, quem as realizou e quais dispositivos foram afetados
SELECT
    m.codigo_manutencao,
    m.status_manutencao,
    a.nome_usuario AS agente_responsavel,
    d.nome_dispositivo
FROM
    manutencao m
LEFT JOIN
    agente a ON m.id_agente = a.id_agente
LEFT JOIN
    dispositivo_manutencao dm ON m.codigo_manutencao = dm.codigo_manutencao
LEFT JOIN
    dispositivo d ON dm.id_dispositivo = d.id_dispositivo
ORDER BY
    m.codigo_manutencao, d.nome_dispositivo;

-- 5. Contar quantos dispositivos estão em cada local
SELECT
    l.nome_local,
    COUNT(d.id_dispositivo) AS total_dispositivos
FROM
    local l
LEFT JOIN
    dispositivo d ON l.codigo_local = d.codigo_local
GROUP BY
    l.nome_local
ORDER BY
    total_dispositivos DESC;

-- Adiciona um novo dispositivo (uma nova luminária)
INSERT INTO dispositivo (nome_dispositivo, cor_dispositivo, modelo_dispositivo, codigo_local, id_comando)
VALUES ('Luminária LED Nova Geração', 'Branca', 'Modelo Neo-Lumen-X', NULL, NULL);

-- Você pode verificar se o dispositivo foi adicionado:
SELECT * FROM dispositivo ORDER BY id_dispositivo DESC LIMIT 1;

-- Atualiza o novo dispositivo (id_dispositivo = 5) para:
-- - Definir sua cor para "Azul"
-- - Associá-lo ao 'Local' de código 2 (Avenida Principal)
-- - Associá-lo ao 'Comando' de ID 1 (Enviado)
UPDATE dispositivo
SET
    cor_dispositivo = 'Azul',
    codigo_local = 2, -- Supondo que o local com id 2 seja a "Avenida Principal"
    id_comando = 1    -- Supondo que o comando com id 1 seja "Enviado"
WHERE
    id_dispositivo = 5; -- AQUI você deve usar o ID REAL do dispositivo que acabou de inserir ou que deseja atualizar

-- Você pode verificar se o dispositivo foi atualizado:
SELECT * FROM dispositivo WHERE id_dispositivo = 5;

-- Primeiro, é uma boa prática verificar se há dependências
-- Ex: Ver se algum sensor está associado a este dispositivo
SELECT * FROM sensor WHERE id_dispositivo = 5;

-- Se houver sensores associados, você precisaria primeiro:
-- 1. Associar esses sensores a outro dispositivo:
--    UPDATE sensor SET id_dispositivo = [ID_DE_OUTRO_DISPOSITIVO] WHERE id_dispositivo = 5;
-- OU
-- 2. Definir o id_dispositivo desses sensores como NULL:
--    UPDATE sensor SET id_dispositivo = NULL WHERE id_dispositivo = 5;
-- OU
-- 3. Deletar esses sensores (se fizer sentido para a lógica de negócio):
--    DELETE FROM sensor WHERE id_dispositivo = 5;

-- Assumindo que você lidou com as dependências ou que não havia nenhuma:

-- Exclui o dispositivo com id_dispositivo = 5
DELETE FROM dispositivo
WHERE id_dispositivo = 5; -- AQUI você deve usar o ID REAL do dispositivo que deseja excluir

-- Você pode verificar se o dispositivo foi excluído:
SELECT * FROM dispositivo WHERE id_dispositivo = 5; -- Não deve retornar nenhum registro

